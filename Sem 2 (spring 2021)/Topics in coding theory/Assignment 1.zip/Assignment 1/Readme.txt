Srikar Kale
2020701018

1) Softwares Used:
Python3
Sympy

2) Softwares which didnt work:
Havent tried out much

3)No of problems completed:
1 a -> Completed
1 b -> Completed
2 -> Completed
3 -> Partial Soln
Works for very few cases

4,5 -> Havent done

Why I couldnt do more?
Couldnt code q3 itself completely
Getting polynomial interpolation error in q4

4) External resources used:
Unique decoding solution from Reed Solomon Wikipedia Article
Brute force approach for generating irreducible polynomial online from math.stackexchange article

5) Collaborations:
Referred to Vaibhav Chimalgi's code for q3

6) Things I have learnt in the assignment:
How to find an irr polynomial using a brute force approach
Finding the primitive element of a Finite field
Understanding the Welch Berlekamp algorithm
Understanding list decoding to some extent

7) Comments to improving programming assignment experience:
None